package br.com.mercado.livre.desafio.service;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class SimioService {
    public boolean isSimian(String[] linhaDeDna) {
        String[][] matriz = convertStringArrayToMatrix(linhaDeDna);
        //Linhaxcoluna
        for (int l = 0; l < matriz.length; l++) {
            for (int c = 0; c < matriz[l].length; c++) {
                String letra = matriz[l][c];
                System.out.printf("%s, ", letra);
            }
            System.out.println();
        }

        return true;
    }

    private String[][] convertStringArrayToMatrix(String[] linhaDeDna) {
        List<String[]> linhas = Stream.of(linhaDeDna).map(linha -> linha.split("(?<=.)")).collect(Collectors.toList());
        int colunas = linhas.get(0).length;
        String[][] matriz = new String[linhas.size()][colunas];
        for (int i = 0; i < matriz.length; i++) {
            matriz[i] = linhas.get(i);
        }
        return matriz;
    }
}
