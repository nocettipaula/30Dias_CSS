package br.com.mercado.livre.desafio.dto;

public class DnaDto {
    private String[] dna;

    public String[] getDna() {
        return dna;
    }
}
