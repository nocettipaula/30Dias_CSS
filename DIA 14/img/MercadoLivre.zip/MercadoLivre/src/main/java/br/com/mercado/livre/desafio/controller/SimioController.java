package br.com.mercado.livre.desafio.controller;

import br.com.mercado.livre.desafio.dto.DnaDto;
import br.com.mercado.livre.desafio.service.SimioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin("*")
@RequestMapping("/simian")
public class SimioController {

    private final SimioService simioService;

    @Autowired
    public SimioController(SimioService simioService) {
        this.simioService = simioService;
    }

    @PostMapping
    public ResponseEntity<?> isSimio(@RequestBody DnaDto dnaDto) {
        if (simioService.isSimian(dnaDto.getDna())) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.status(403).build();
    }
}
